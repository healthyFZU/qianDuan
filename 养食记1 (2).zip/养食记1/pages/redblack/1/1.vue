<template>
  <view class="top-card">
    <!-- 添加两个按钮 -->
    <button class="top-card-text recommend" @click="navigateToRecommend">推荐食用</button>
    <button class="top-card caution" @click="navigateToCaution">谨慎食用</button>
  </view>
  <scroll-view style="flex: 1; padding: 10px;">
    <div class="food-list">
      <div class="food-item" v-for="item in foodItems" :key="item.name">
        <img :src="item.image" alt="" class="food-image"/>
        <div class="food-info">
          <p class="food-name">{{ item.name }}</p>
          <p class="food-calories">
            <span class="calories-number">{{ item.calories }}</span> 
            <span class="calories-unit">千卡/100克</span>
          </p>
        </div>
      </div>
    </div>
  </scroll-view>
</template>

<script>
export default {
data() {
return {
foodItems: [
{ name: '芦荟（鲜）', calories: 4, image: '/static/fruit/luhui.png' },
{ name: '白粉桃', calories: 26, image:  '/static/fruit/peach.png' },
{ name: '甜瓜', calories: 26, image: '/static/fruit/gua.png' },
{ name: '青木瓜', calories: 29, image: '/static/fruit/qinggua.png' },
{ name: '西瓜（黄肉小瓜）', calories: 29, image: '/static/fruit/yellow.png' },
{ name: '木瓜', calories: 30, image: '/static/fruit/mugua.png' },
{ name: '杨梅', calories: 30, image: '/static/fruit/yangmei.png' },
{ name: '杨桃', calories: 31, image: '/static/fruit/yangtao.png' },
{ name: '西瓜', calories: 31, image: '/static/fruit/xigua.png' },
{ name: '草莓', calories: 32, image: '/static/fruit/caomei.png' }
]
}
},
methods: {
    navigateToRecommend() {
     // 点击“推荐食用”按钮时跳转到的页面
     uni.navigateTo({
        url: '/pages/redblack/1/1'
      });
   },
   navigateToCaution() {
     // 点击“谨慎食用”按钮时跳转到的页面
     uni.navigateTo({
        url: '/pages/redblack/1/2'
      });
   }
  }
}
</script>

<style>
	.top-card {
	    display: flex;
	    justify-content: space-between; /* 使按钮水平分布 */
	    align-items: center;
	    margin-bottom: 10px;
	  }
	
	  .top-card-text {
	    font-size: 10px;
	    font-weight: bold;
	    margin: 0 10px; /* 调整按钮间的间距 */
	    padding: 10px 20px; /* 按钮内边距 */
	    border: none;
	    background-color: #ffffff; /* 按钮背景色 */
	    cursor: pointer; /* 鼠标悬停在上面时显示指针 */
	  }
	
	
.recommend {
    color: #4CAF50; /* 推荐食用按钮文本颜色 */
  }

  .caution {
    color: #F44D4F; /* 谨慎食用按钮文本颜色 */
  }
  
.food-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  
}

.food-item {
  display: flex;
  align-items: center;
  padding: 10px 0;
  border-bottom: 1px solid #eee;
}

.food-image {
  width: 50px;
  height: 50px;
  margin-right: 15px;
}

.food-info {
  display: flex;
  flex-direction: column;
}

.food-name {
  font-size: 14px;
  font-weight: bold;
}

.food-calories {
  font-size: 13px;
}

.calories-number {
  color: #ff4d4f; /* 保持数字的红色 */
}

.calories-unit {
  color: #b0b0b0; /* 浅灰色 */
}
</style>
